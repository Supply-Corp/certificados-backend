import { sequelize } from "./mysql";

export class DatabaseConfig {

    constructor() {}

    static async testConnection() {
        try {
            await sequelize.sync({ force: false });
            console.log(`database connected`);
        } catch (error) {
            console.log(`error database connection ${ error }`);
        }
    }

}