import { DataTypes, Model, Sequelize } from "sequelize";
import { envs } from "../../config";

export const sequelize = new Sequelize(`${envs.DATABASE_URL}`); // Example for postgres

// Enumeraciones
const Role = {
  USER: "USER",
  ADMIN: "ADMIN",
};

const States = {
  ACTIVE: "ACTIVE",
  DELETED: "DELETED",
};

// Modelo User
class User extends Model {}
User.init(
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: DataTypes.STRING,
    lastName: DataTypes.STRING,
    documentNumber: DataTypes.STRING,
    email: { type: DataTypes.STRING, unique: true },
    password: DataTypes.STRING,
    role: {
      type: DataTypes.ENUM,
      values: Object.values(Role),
      defaultValue: Role.USER,
    },
    recoveryPassword: { type: DataTypes.BOOLEAN, allowNull: true },
    createdAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  { sequelize, modelName: "user" }
);

// Modelo Courses
class Courses extends Model {}
Courses.init(
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: DataTypes.STRING,
    initialDate: DataTypes.DATE,
    endDate: DataTypes.DATE,
    state: {
      type: DataTypes.ENUM,
      values: Object.values(States),
      defaultValue: States.ACTIVE,
    },
    createdAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  { sequelize, modelName: "courses" }
);


// Modelo Templates
class Templates extends Model {}
Templates.init(
  {
    id: { 
        type: DataTypes.INTEGER, 
        primaryKey: true, 
        autoIncrement: true 
    },
    name: DataTypes.STRING,
    file: DataTypes.STRING,
    state: {
      type: DataTypes.ENUM,
      values: Object.values(States),
      defaultValue: States.ACTIVE,
    },
    createdAt: { 
        type: DataTypes.DATE, 
        defaultValue: DataTypes.NOW 
    },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  { sequelize, modelName: "templates" }
);

// Modelo UserCourses
class UserCourses extends Model {}

UserCourses.init(
  {
    id: { 
        type: DataTypes.INTEGER, 
        primaryKey: true, 
        autoIncrement: true 
    },
    identifier: { 
        type: DataTypes.STRING,
        unique: true 
    },
    userId: { 
        type: DataTypes.INTEGER, 
        references: { 
            model: User, 
            key: "id" 
        } 
    },
    templateId: {
      type: DataTypes.INTEGER,
      references: {
        model: Templates,
        key: 'id'
      }
    },
    courseId: {
        type: DataTypes.INTEGER,
        references: { 
            model: Courses, 
            key: "id" 
        },
    },
    hours: DataTypes.INTEGER,
    createdAt: { 
        type: DataTypes.DATE, 
        defaultValue: DataTypes.NOW 
    },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  { sequelize, modelName: "user_courses" }
);
