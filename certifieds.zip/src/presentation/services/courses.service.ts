import { CourseEntity, CreateCoursesDto, CustomError, PaginationDto, UpdateCoursesDto } from '../../domain';
import { PaginationService } from './pagination.service';

export enum States {
    ACTIVE = 'ACTIVE',
    DELETED = 'DELETED'
}

export class CoursesService {

    constructor() {}

    async listCourse( dto: PaginationDto ) {

        // const { page, limit, search } = dto;

        // const [total, courses] = await Promise.all([
        //     await prisma.courses.count({ where: { state: States.ACTIVE } }),
        //     await prisma.courses.findMany({
        //         skip: (page - 1) * limit,
        //         take: limit,
        //         where: {
        //             state: States.ACTIVE,
        //             AND: [{
        //                 ...(search && {
        //                     name: {
        //                         startsWith: `%${ search }`
        //                     }
        //                 })
        //             }]
        //         }
        //     })
        // ]);

        // const pagination = PaginationService.get(page, limit, total, '/api/courses');

        // return {
        //     ...pagination,
        //     courses: courses.map(CourseEntity.fromObject)
        // }

    }

    async getCourse( id: number ) {

        // const course = await prisma.courses.findFirst({ where: { id } });
        // if( !course ) throw CustomError.notFound('El cursos solicitado no existe');

        // if( course.state === 'DELETED') throw CustomError.notFound('El cursos solicitado no existe');

        // return {
        //     ...CourseEntity.fromObject(course)
        // }

    }

    async createCourse(dto: CreateCoursesDto) {
        try {
            // const course = await prisma.courses.create({
            //     data: {
            //         ...dto,
            //         initialDate: new Date(dto.initialDate),
            //         endDate: new Date(dto.endDate)
            //     }
            // });

            // return {
            //     ...CourseEntity.fromObject(course)
            // }

        } catch (error) {
            throw CustomError.internalServe(`${ error }`)
        }
    }

    async updateCourse( dto: UpdateCoursesDto) {
        // const exist = await prisma.courses.findFirst({ where: { id: dto.id } });
        // if( !exist ) throw CustomError.notFound('El curso no existe');

        // if( exist.state === 'DELETED') throw CustomError.notFound('El curso no existe');
        
        try {
            // const { id, ...data } = dto;

            // const update = await prisma.courses.update({ 
            //     where: { id: dto.id },
            //     data: { ...data,
            //         initialDate: data.initialDate ? new Date(data.initialDate) : exist.initialDate,
            //         endDate: data.endDate ? new Date(data.endDate) : exist.endDate,
            //     }
            // });

            // return {
            //     ...CourseEntity.fromObject(update)
            // }

        } catch (error) {
            throw CustomError.internalServe(`${ error }`);
        }
    }

    async deleteCourse(id: number) {
        // const exist = await prisma.courses.findFirst({ where: { id } });
        // if( !exist ) throw CustomError.notFound('El curso no existe');

        // if( exist.state === 'DELETED') throw CustomError.notFound('El curso no existe');

        try {
            
            // const update = await prisma.courses.update({ 
            //     where: { id },
            //     data: { state: States.DELETED }
            // });

            // return {
            //     ...CourseEntity.fromObject(update)
            // }
            
        } catch (error) {
            throw CustomError.internalServe(`${ error }`);
        }

    }

}