

export class ValidateUserCourse {

    static async validateUser( value: string ) {
        
        // const exist = await prisma.user.findFirst({ where: { id: +value } });
        // if( !exist ) throw new Error('usuario inválido o no existe');

        return true;
    }

    static async validateCourse( value: string ) {
        
        // const exist = await prisma.courses.findFirst({ where: { id: +value } });
        // if( !exist ) throw new Error('curso inválido o no existe');

        return true;
    }

    static async validateTemplate( value: string ) {
        
        // const exist = await prisma.templates.findFirst({ where: { id: +value } });
        // if( !exist ) throw new Error('template inválido o no existe');

        return true;
    }

}