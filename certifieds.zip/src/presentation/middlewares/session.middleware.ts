import { NextFunction, Request, Response } from "express";
import { JwtAdapter } from "../../config";

import { UserEntity } from '../../domain/entities/user.entity';

export class SessionMiddleware {

    constructor() {}

    static async validateJwt(req: Request, res: Response, next: NextFunction) {

        const authorization = req.header('Authorization');

        if( !authorization ) return res.status(401).json({ error: 'Token no proveído' });
        if( !authorization.startsWith('Bearer ')) return res.status(401).json({ error: 'Invalid Bearer token'});

        const token = authorization.split(' ').at(1) || '';

        try {
            const payload = await JwtAdapter.validateToken<{ id: number }>( token );
            if( !payload ) return res.status(401).json({ error: 'Invalid token' });

            // const user = await prisma.user.findFirst({ where: { id: payload.id }});
            // if( !user ) return res.status(401).json({ error: 'Error token validation information.'});

            // const { password, ...userEntity } = UserEntity.fromObject( user );
            // req.body.user = userEntity;

            next();
        } catch (error) {
            console.error( error );
            return res.status(500).json({ error: 'Internal server error.'});
        }
    }

}